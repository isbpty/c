import { db } from "./db";
import { 
  surveys, responses,
  type Survey, type InsertSurvey, 
  type Response, type InsertResponse 
} from "@shared/schema";
import { eq } from "drizzle-orm";
import { randomBytes } from "crypto";

export interface IStorage {
  // Survey operations
  createSurvey(survey: InsertSurvey): Promise<Survey>;
  getSurveyByPublicId(publicId: string): Promise<Survey | undefined>;
  getSurveyByDomToken(domToken: string): Promise<Survey | undefined>;
  getSurveyById(id: number): Promise<Survey | undefined>;
  updateSurveyStatus(id: number, status: string): Promise<Survey>;
  updateSurveySpice(id: number, backstory: string): Promise<Survey>;
  updateSurveyStory(id: number, story: string, prompt: string): Promise<Survey>;
  
  // Response operations
  createResponse(response: InsertResponse & { surveyId: number }): Promise<Response>;
  getResponseBySurveyId(surveyId: number): Promise<Response | undefined>;
}

export class DatabaseStorage implements IStorage {
  async createSurvey(insertSurvey: InsertSurvey): Promise<Survey> {
    const publicId = randomBytes(8).toString('hex');
    const domToken = randomBytes(16).toString('hex');
    const [survey] = await db.insert(surveys).values({
      ...insertSurvey,
      publicId,
      domToken,
      status: 'created'
    }).returning();
    return survey;
  }

  async getSurveyByPublicId(publicId: string): Promise<Survey | undefined> {
    const [survey] = await db.select().from(surveys).where(eq(surveys.publicId, publicId));
    return survey;
  }

  async getSurveyByDomToken(domToken: string): Promise<Survey | undefined> {
    const [survey] = await db.select().from(surveys).where(eq(surveys.domToken, domToken));
    return survey;
  }

  async getSurveyById(id: number): Promise<Survey | undefined> {
    const [survey] = await db.select().from(surveys).where(eq(surveys.id, id));
    return survey;
  }

  async updateSurveyStatus(id: number, status: string): Promise<Survey> {
    const [survey] = await db.update(surveys)
      .set({ status })
      .where(eq(surveys.id, id))
      .returning();
    return survey;
  }

  async updateSurveySpice(id: number, backstory: string): Promise<Survey> {
    const [survey] = await db.update(surveys)
      .set({ domBackstory: backstory })
      .where(eq(surveys.id, id))
      .returning();
    return survey;
  }

  async updateSurveyStory(id: number, story: string, prompt: string): Promise<Survey> {
    const [survey] = await db.update(surveys)
      .set({ 
        generatedStory: story, 
        generatedPrompt: prompt,
        status: 'completed' 
      })
      .where(eq(surveys.id, id))
      .returning();
    return survey;
  }

  async createResponse(insertResponse: InsertResponse & { surveyId: number }): Promise<Response> {
    const [response] = await db.insert(responses).values({
      surveyId: insertResponse.surveyId,
      hardLimits: insertResponse.hardLimits,
      safeword: insertResponse.safeword,
      preferences: insertResponse.preferences,
    }).returning();
    return response;
  }

  async getResponseBySurveyId(surveyId: number): Promise<Response | undefined> {
    const [response] = await db.select().from(responses).where(eq(responses.surveyId, surveyId));
    return response;
  }
}

export const storage = new DatabaseStorage();
