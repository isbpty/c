import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Create Survey
  app.post(api.surveys.create.path, async (req, res) => {
    try {
      const input = api.surveys.create.input.parse(req.body);
      const survey = await storage.createSurvey(input);
      res.status(201).json({
        publicId: survey.publicId,
        domToken: survey.domToken,
        domName: survey.domName,
        subName: survey.subName,
      });
    } catch (err: any) {
      console.error("CREATE SURVEY ERROR:", err);
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Dom Dashboard
  app.get(api.surveys.getDashboard.path, async (req, res) => {
    const survey = await storage.getSurveyByDomToken(req.params.domToken);
    if (!survey) {
      return res.status(404).json({ message: 'Dashboard not found' });
    }
    
    const response = await storage.getResponseBySurveyId(survey.id);
    
    res.json({
      id: survey.id,
      publicId: survey.publicId,
      domName: survey.domName,
      subName: survey.subName,
      sceneLength: survey.sceneLength,
      status: survey.status,
      domBackstory: survey.domBackstory,
      generatedStory: survey.generatedStory,
      hasSubResponded: !!response,
    });
  });

  // Update Spice
  app.post(api.surveys.updateSpice.path, async (req, res) => {
    const survey = await storage.getSurveyByDomToken(req.params.domToken);
    if (!survey) {
      return res.status(404).json({ message: 'Survey not found' });
    }
    const { backstory } = req.body;
    await storage.updateSurveySpice(survey.id, backstory || "");
    res.json({ success: true });
  });

  // Get Survey (Sub View)
  app.get(api.surveys.getByPublicId.path, async (req, res) => {
    const survey = await storage.getSurveyByPublicId(req.params.publicId);
    if (!survey) {
      return res.status(404).json({ message: 'Survey not found' });
    }
    res.json({
      id: survey.id,
      publicId: survey.publicId,
      domName: survey.domName,
      subName: survey.subName,
      sceneLength: survey.sceneLength,
      status: survey.status,
    });
  });

  // Submit Response
  app.post(api.surveys.submitResponse.path, async (req, res) => {
    try {
      const { publicId } = req.params;
      const survey = await storage.getSurveyByPublicId(publicId);
      if (!survey) {
        return res.status(404).json({ message: 'Survey not found' });
      }

      // Check if already responded
      if (survey.status !== 'created') {
        return res.status(400).json({ message: 'This link has already been used and is now inactive.' });
      }

      const input = api.surveys.submitResponse.input.parse(req.body);
      await storage.createResponse({ ...input, surveyId: survey.id });
      await storage.updateSurveyStatus(survey.id, 'responded');

      res.json({ success: true });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Generate Story (AI)
  app.post(api.surveys.generateStory.path, async (req, res) => {
    try {
      const { publicId } = req.params;
      // Also try to find by ID if publicId is a number string (frontend might pass it)
      let survey = await storage.getSurveyByPublicId(publicId);
      if (!survey && !isNaN(Number(publicId))) {
        survey = await storage.getSurveyById(Number(publicId));
      }

      if (!survey) {
        return res.status(404).json({ message: 'Survey not found' });
      }

      const response = await storage.getResponseBySurveyId(survey.id);
      if (!response) {
        return res.status(400).json({ message: 'No response submitted yet' });
      }

      const analysis = analyzePreferences(response.preferences);
      const safewordDesc = response.safeword || "RED";
      
      const systemPrompt = `You are an expert BDSM scene designer. Create a detailed, consensual ${survey.sceneLength === 1 ? '15-30 minute' : survey.sceneLength === 2 ? '1-2 hour' : 'day-long'} scene.`;
      const userPrompt = `
        Dominant: ${survey.domName}
        Submissive: ${survey.subName}
        
        **SAFETY PROTOCOLS:**
        Hard Limits: ${response.hardLimits || 'None specified'}
        Safeword: ${safewordDesc}
        
        **Dominant's Vision & Context:**
        ${survey.domBackstory || 'No specific backstory provided.'}
        
        **Submissive's Private Desires (Mystery Factor):**
        CORE THEMES: ${analysis.coreActivities}
        SECONDARY ELEMENTS: ${analysis.lightActivities}
        SURPRISE TWISTS: ${analysis.surpriseElements}
        
        **STRICTLY FORBIDDEN:** ${analysis.avoidList}
        
        Create a complete, immersive BDSM scenario that weaves the Dom's vision with the Sub's hidden desires.
        The Dom should feel like they are leading a scene crafted specifically for their sub's deepest (previously unstated) wishes.
        Include: Roleplay Setup, Props/Gear list, Scene Flow (Phase 1, 2, 3), and Aftercare.
        Use seductive, high-quality prose.
      `;

      const aiResponse = await openai.chat.completions.create({
        model: "gpt-4o", // Using gpt-4o as it is stable and smart
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
      });

      const story = aiResponse.choices[0].message.content || "Failed to generate story.";
      
      await storage.updateSurveyStory(survey.id, story, userPrompt);

      res.json({ story, prompt: userPrompt });

    } catch (err) {
      console.error("STORY GEN ERROR:", err);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}

function analyzePreferences(preferences: Record<string, { value: number; hardNo: boolean }>) {
  const core: string[] = [];
  const light: string[] = [];
  const avoid: string[] = [];
  const surprise: string[] = [];

  for (const [key, pref] of Object.entries(preferences)) {
    const itemName = key.replace(/_/g, ' '); 
    if (pref.hardNo || pref.value <= 2) {
      avoid.push(itemName);
    } else if (pref.value >= 7) {
      core.push(`${itemName}`);
    } else if (pref.value >= 3) {
      light.push(`${itemName}`);
      if (Math.random() > 0.7) surprise.push(itemName);
    }
  }

  return {
    coreActivities: core.join(', ') || "None",
    lightActivities: light.join(', ') || "None",
    surpriseElements: surprise.join(', ') || "None",
    avoidList: avoid.join(', ') || "None",
  };
}
