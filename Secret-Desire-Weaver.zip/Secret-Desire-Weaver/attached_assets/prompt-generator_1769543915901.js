// ================================
// AI PROMPT GENERATOR - COMPLETE
// Creates dynamic prompts based on sub's preferences
// This is what makes each scene unique!
// ================================
const PromptGenerator = {
    generate(surveyData) {
        const analysis = this.analyzePreferences(surveyData.preferences);
        const safewordDesc = this.getSafewordDescription(surveyData.safeword);
        const dayStructure = this.getDayStructure(surveyData.sceneLength);
        
        return `You are an expert BDSM scene designer. Create a detailed, consensual ${surveyData.sceneLength}-day scene for:
- Dom: ${surveyData.domName}
- Sub: ${surveyData.subName}

**SAFETY FIRST:**
Hard Limits: ${surveyData.hardLimits || 'None specified'}
Safeword: ${safewordDesc}
All activities must be SAFE, SANE, and CONSENSUAL.

**Scene Parameters:**
Duration: ${surveyData.sceneLength} day(s)
Intensity Level: ${analysis.intensity}
Tone: Immersive, R-rated, consensual power exchange

**Activity Preferences (Personalized):**

PRIMARY FOCUS (70% of scene):
${analysis.coreActivities}

LIGHT TOUCHES (20% of scene):
${analysis.lightActivities}

SURPRISE ELEMENTS (10% variety):
${analysis.surpriseElements}

**STRICTLY AVOID:**
${analysis.avoidList}

**Required Output Format:**

1. **Backstory & Setup** (2-3 paragraphs)
Create an engaging scenario explaining why ${surveyData.domName} and ${surveyData.subName} are doing this scene. Set the mood and dynamic.

2. **Day-by-Day Schedule**
${dayStructure}

3. **Props & Preparation**
Complete shopping list of items needed with notes on safety/preparation.

4. **Scene Flow**
- Opening Ritual: How the scene begins
- Gradual Build-up: Slowly increase intensity
- Peak Moments: Main activities/climax
- Cool-down: Gentle ending and transition

5. **Safeword Protocol**
${safewordDesc}
Explain clearly when and how to use it, plus check-in frequency.

6. **Aftercare Plan** (MANDATORY)
- Physical Care: Water, snacks, blankets, shower together
- Emotional Care: Cuddles, affirmations, gentle conversation
- Debriefing: What worked, what didn't
- Next-Day Check-in: Text or call to ensure they're okay

**Writing Guidelines:**
- Use ${surveyData.domName} and ${surveyData.subName} by name throughout
- Write in immersive present tense
- Include realistic dialogue
- R-rated content (sexy but tasteful, no explicit porn)
- Balance dominance with care and affection
- Make it feel personal and intimate

Create a complete, ready-to-use scene that prioritizes safety and pleasure.`;
    },

    analyzePreferences(preferences) {
        const core = [];      // 7-10 rating (love it)
        const light = [];     // 3-6 rating (neutral/like)
        const avoid = [];     // 0-2 or hardNo (hate it)
        const surprise = [];  // mid-range for variety

        // Categorize each preference
        for (const key in preferences) {
            const pref = preferences[key];
            const itemName = this.getItemName(key);
            
            if (!itemName) continue;

            if (pref.hardNo || pref.value <= 2) {
                avoid.push(itemName);
            } else if (pref.value >= 7) {
                core.push({ 
                    name: itemName, 
                    value: pref.value, 
                    category: this.getCategoryFromKey(key) 
                });
            } else if (pref.value >= 3 && pref.value <= 6) {
                light.push({ 
                    name: itemName, 
                    value: pref.value, 
                    category: this.getCategoryFromKey(key) 
                });
            }
        }

        // Select random items for surprise (from mid-range preferences)
        if (light.length > 3) {
            const shuffled = [...light].sort(() => 0.5 - Math.random());
            surprise.push(...shuffled.slice(0, Math.min(2, light.length)));
        }

        // Format the analysis
        return {
            intensity: this.calculateIntensity(core, light),
            coreActivities: this.formatActivities(core, 'These are highly desired'),
            lightActivities: this.formatActivities(light, 'Use sparingly as accents'),
            surpriseElements: this.formatActivities(surprise, 'Add for variety'),
            avoidList: avoid.length > 0 ? avoid.join(', ') : 'None specified'
        };
    },

    calculateIntensity(core, light) {
        const coreCount = core.length;
        const totalScore = core.reduce((sum, item) => sum + item.value, 0);
        const avgScore = coreCount > 0 ? totalScore / coreCount : 5;

        if (avgScore >= 9 && coreCount >= 5) {
            return 'High Intensity (Experienced)';
        } else if (avgScore >= 7) {
            return 'Medium-High Intensity';
        } else if (avgScore >= 5) {
            return 'Medium Intensity (Comfortable)';
        } else {
            return 'Light Intensity (Beginner-Friendly)';
        }
    },

    formatActivities(activities, description) {
        if (activities.length === 0) {
            return 'None specified - Use your best judgment';
        }
        
        let output = `${description}:\n`;
        
        // Group by category
        const grouped = {};
        activities.forEach(item => {
            if (!grouped[item.category]) {
                grouped[item.category] = [];
            }
            grouped[item.category].push(item.name);
        });

        // Format each category
        for (const category in grouped) {
            output += `- ${category}: ${grouped[category].join(', ')}\n`;
        }

        return output;
    },

    getItemName(key) {
        // Parse key like "Bondage_0" to get the actual item name
        const parts = key.split('_');
        if (parts.length < 2) return null;
        
        const itemIndex = parseInt(parts[parts.length - 1]);
        
        // Find the matching category
        for (const category in FETISH_DATA) {
            if (key.startsWith(category)) {
                const items = FETISH_DATA[category];
                if (items && items[itemIndex]) {
                    return items[itemIndex];
                }
            }
        }
        
        return null;
    },

    getCategoryFromKey(key) {
        // Extract category name from key like "Bondage_0"
        for (const category in FETISH_DATA) {
            if (key.startsWith(category)) {
                return category;
            }
        }
        return 'Unknown';
    },

    getSafewordDescription(safeword) {
        switch(safeword) {
            case 'traffic':
                return 'Traffic Light System - Green (all good, continue), Yellow (slow down/check in), Red (stop immediately)';
            case 'standard':
                return 'Standard Safeword "RED" - saying this stops everything immediately';
            default:
                // Custom safeword
                return `Safeword: "${safeword}" - saying this stops everything immediately`;
        }
    },

    getDayStructure(days) {
        let structure = '';
        for (let i = 1; i <= days; i++) {
            structure += `**Day ${i}:**\n`;
            structure += `- Morning (8am-12pm): [Light activities, teasing, tasks]\n`;
            structure += `- Afternoon (12pm-6pm): [Build-up, more intense activities]\n`;
            structure += `- Evening (6pm-10pm): [Peak intensity, main scene]\n`;
            structure += `- Night (10pm+): [Wind down, aftercare]\n`;
            
            if (i < days) {
                structure += `\n`;
            }
        }
        return structure;
    }
};
