// ================================
// DOM INTERFACE - Landing page where Dom creates the survey
// ================================
const DomInterface = {
    init() {
        // Check if there's a completed survey to view
        const hash = window.location.hash.substring(1);
        if (hash && hash.includes('_complete')) {
            this.showResults(hash.replace('_complete', ''));
            return;
        }
    },

    generateLink() {
        const domName = document.getElementById('domName').value.trim();
        const subName = document.getElementById('subName').value.trim();
        const sceneLength = document.getElementById('sceneLength').value;

        if (!domName || !subName) {
            alert('Please enter both names');
            return;
        }

        const sessionId = this.generateId();
        const surveyData = {
            domName,
            subName,
            sceneLength,
            timestamp: Date.now()
        };

        // Save to localStorage
        localStorage.setItem('survey_' + sessionId, JSON.stringify(surveyData));

        // Generate and display link
        const surveyLink = window.location.origin + window.location.pathname + '#' + sessionId;
        document.getElementById('surveyLink').textContent = surveyLink;
        document.getElementById('linkContainer').classList.remove('hidden');
    },

    generateId() {
        return 'survey_' + Math.random().toString(36).substring(2, 15) + 
               Math.random().toString(36).substring(2, 15);
    },

    copyLink() {
        const linkText = document.getElementById('surveyLink').textContent;
        navigator.clipboard.writeText(linkText).then(() => {
            alert('✅ Link copied! Send it to your partner.');
        }).catch(() => {
            alert('Please copy the link manually');
        });
    },

    showResults(sessionId) {
        const resultData = localStorage.getItem('survey_' + sessionId + '_complete');
        if (!resultData) {
            alert('Survey not completed yet or expired');
            window.location.hash = '';
            location.reload();
            return;
        }

        const data = JSON.parse(resultData);
        document.getElementById('promptOutput').textContent = data.prompt;
        this.showView('domView');
    },

    copyPrompt() {
        const prompt = document.getElementById('promptOutput').textContent;
        navigator.clipboard.writeText(prompt).then(() => {
            alert('✅ Prompt copied! Paste it into ChatGPT or Claude.');
        });
    },

    downloadPrompt() {
        const prompt = document.getElementById('promptOutput').textContent;
        const blob = new Blob([prompt], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'bdsm-scene-prompt.txt';
        a.click();
        URL.revokeObjectURL(url);
    },

    startOver() {
        window.location.hash = '';
        location.reload();
    },

    showView(viewId) {
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        document.getElementById(viewId).classList.add('active');
        window.scrollTo(0, 0);
    }
};
