// ================================
// MAIN APP - Initialization and routing
// ================================
const App = {
    init() {
        // Check URL hash to determine which view to show
        const hash = window.location.hash.substring(1);
        
        if (!hash) {
            // Show landing page for Dom
            this.showView('landingView');
        } else if (hash.includes('_complete')) {
            // Show results to Dom
            DomInterface.showResults(hash.replace('_complete', ''));
        } else {
            // Show survey to Sub
            SubInterface.init(hash);
        }
    },

    showView(viewId) {
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        const view = document.getElementById(viewId);
        if (view) {
            view.classList.add('active');
        }
        window.scrollTo(0, 0);
    },

    // Proxy methods to keep onclick handlers simple
    generateLink() {
        DomInterface.generateLink();
    },

    copyLink() {
        DomInterface.copyLink();
    },

    copyPrompt() {
        DomInterface.copyPrompt();
    },

    downloadPrompt() {
        DomInterface.downloadPrompt();
    },

    startOver() {
        DomInterface.startOver();
    },

    nextStep() {
        SubInterface.nextStep();
    },

    prevStep() {
        SubInterface.prevStep();
    },

    acceptConsent() {
        SubInterface.acceptConsent();
    },

    declineConsent() {
        SubInterface.declineConsent();
    }
};

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});
