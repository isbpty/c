// ================================
// FETISH DATA - CUSTOMIZE HERE
// Add/remove/edit categories and items easily
// ================================
const FETISH_DATA = {
    'Bondage': [
        'Rope Bondage',
        'Handcuffs/Restraints',
        'Spreader Bars',
        'Hogtie Position',
        'Mummification'
    ],
    'Impact Play': [
        'Spanking (Hand)',
        'Paddling',
        'Flogging/Whipping',
        'Nipple Clamps',
        'Cropping'
    ],
    'Sensory Play': [
        'Blindfolds',
        'Ice Play',
        'Hot Wax',
        'Feather Teasing',
        'Sensory Deprivation Hood'
    ],
    'Toys & Tools': [
        'Butt Plugs',
        'Vibrators',
        'Dildos',
        'Cock Cage/Chastity',
        'Ben Wa Balls'
    ],
    'Humiliation': [
        'Verbal Degradation',
        'Physical Tasks (Crawling, Kneeling)',
        'Public Humiliation (Safe)',
        'Writing Lines/Assignments',
        'Name Calling'
    ],
    'Tease & Denial': [
        'Edging',
        'Orgasm Denial',
        'Ruined Orgasms',
        'Forced Orgasms',
        'Chastity Training'
    ],
    'Roleplay': [
        'Pet Play (Collar/Leash)',
        'Teacher/Student',
        'Master/Slave',
        'Boss/Employee',
        'Captor/Captive'
    ],
    'Advanced Play': [
        'Pegging',
        'Foot Worship',
        'Body Worship',
        'Breath Play (Caution)',
        'Temperature Play'
    ],
    'Extreme (Optional)': [
        'Electro Stimulation',
        'Watersports',
        'Knife Play (Safe)',
        'Blood Play (Safe)',
        'CNC Roleplay'
    ]
};
