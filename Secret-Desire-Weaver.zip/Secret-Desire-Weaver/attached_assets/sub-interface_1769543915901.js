// ================================
// SUB INTERFACE - Multi-step wizard for sub to fill out
// ================================
const SubInterface = {
    currentStep: 0,
    sessionId: '',
    surveyData: {
        domName: '',
        subName: '',
        sceneLength: 1,
        hardLimits: '',
        safeword: '',
        preferences: {}
    },

    init(sessionId) {
        this.sessionId = sessionId;
        const data = localStorage.getItem('survey_' + sessionId);
        
        if (!data) {
            alert('Invalid or expired survey link');
            window.location.hash = '';
            location.reload();
            return;
        }

        const parsed = JSON.parse(data);
        this.surveyData.domName = parsed.domName;
        this.surveyData.subName = parsed.subName;
        this.surveyData.sceneLength = parsed.sceneLength;

        this.showConsentModal();
    },

    showConsentModal() {
        document.getElementById('consentModal').classList.add('active');
    },

    acceptConsent() {
        document.getElementById('consentModal').classList.remove('active');
        DomInterface.showView('wizardView');
        this.renderStep();
    },

    declineConsent() {
        alert('You must consent to participate. Redirecting...');
        window.location.hash = '';
        location.reload();
    },

    renderStep() {
        const content = document.getElementById('wizardContent');
        const categories = Object.keys(FETISH_DATA);
        const totalSteps = categories.length + 1;
        const progress = (this.currentStep / totalSteps) * 100;
        
        document.getElementById('progressBar').style.width = progress + '%';
        document.getElementById('stepIndicator').textContent = `Step ${this.currentStep + 1} of ${totalSteps}`;

        if (this.currentStep === 0) {
            this.renderInfoStep(content);
        } else if (this.currentStep <= categories.length) {
            this.renderCategoryStep(content, categories[this.currentStep - 1]);
        }

        // Update navigation buttons
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        
        if (this.currentStep > 0) {
            prevBtn.classList.remove('hidden');
        } else {
            prevBtn.classList.add('hidden');
        }

        nextBtn.textContent = this.currentStep >= categories.length ? 'Complete Survey' : 'Next';
    },

    renderInfoStep(content) {
        content.innerHTML = `
            <h2>Welcome, ${this.surveyData.subName}</h2>
            <p style="color: var(--text-secondary); margin-bottom: 2rem;">
                ${this.surveyData.domName} has invited you to complete this confidential survey. 
                Your responses will help create a personalized, consensual scene just for you.
            </p>
            
            <div class="input-group">
                <label>Hard Limits / Injuries / Allergies:</label>
                <textarea id="hardLimits" placeholder="List anything you absolutely don't want, or physical conditions to be aware of...">${this.surveyData.hardLimits || ''}</textarea>
                <small style="color: var(--text-secondary); margin-top: 0.5rem; display: block;">
                    Example: "No face slapping, old shoulder injury, latex allergy"
                </small>
            </div>
            
            <div class="input-group">
                <label>Safeword System:</label>
                <select id="safeword">
                    <option value="traffic">Traffic Lights (Yellow = Slow Down, Red = Stop)</option>
                    <option value="standard">Standard Safeword (Red)</option>
                    <option value="custom">Custom Safeword</option>
                </select>
            </div>
            
            <div class="input-group hidden" id="customSafewordContainer">
                <label>Your Safeword:</label>
                <input type="text" id="customSafeword" placeholder="Enter your safeword">
            </div>
        `;
        
        document.getElementById('safeword').addEventListener('change', (e) => {
            const container = document.getElementById('customSafewordContainer');
            if (e.target.value === 'custom') {
                container.classList.remove('hidden');
            } else {
                container.classList.add('hidden');
            }
        });
    },

    renderCategoryStep(content, category) {
        const items = FETISH_DATA[category];
        let html = `<h2 class="category-title">${category}</h2>`;
        
        items.forEach((item, index) => {
            const key = `${category}_${index}`;
            const savedValue = this.surveyData.preferences[key] || { value: 5, hardNo: false };
            
            html += `
                <div class="fetish-item">
                    <div class="fetish-header">
                        <div class="fetish-name">${item}</div>
                        <div class="hard-no">
                            <input type="checkbox" 
                                   id="hardno_${key}" 
                                   ${savedValue.hardNo ? 'checked' : ''} 
                                   onchange="SubInterface.updateHardNo('${key}', this.checked)">
                            <label for="hardno_${key}">Hard No</label>
                        </div>
                    </div>
                    <div class="slider-container">
                        <input type="range" 
                               min="0" 
                               max="10" 
                               value="${savedValue.value}" 
                               id="slider_${key}" 
                               onchange="SubInterface.updateSlider('${key}', this.value)"
                               oninput="SubInterface.showSliderValue('${key}', this.value)">
                        <div class="slider-labels">
                            <span>0 - Hate It</span>
                            <span>5 - Neutral</span>
                            <span>10 - Love It</span>
                        </div>
                        <div class="slider-value" id="value_${key}">${savedValue.value}</div>
                    </div>
                </div>
            `;
        });
        
        content.innerHTML = html;
    },

    showSliderValue(key, value) {
        document.getElementById('value_' + key).textContent = value;
    },

    updateSlider(key, value) {
        if (!this.surveyData.preferences[key]) {
            this.surveyData.preferences[key] = { value: 5, hardNo: false };
        }
        this.surveyData.preferences[key].value = parseInt(value);
    },

    updateHardNo(key, checked) {
        if (!this.surveyData.preferences[key]) {
            this.surveyData.preferences[key] = { value: 5, hardNo: false };
        }
        this.surveyData.preferences[key].hardNo = checked;
        
        if (checked) {
            document.getElementById('slider_' + key).value = 0;
            this.surveyData.preferences[key].value = 0;
            this.showSliderValue(key, 0);
        }
    },

    nextStep() {
        if (this.currentStep === 0) {
            this.surveyData.hardLimits = document.getElementById('hardLimits').value;
            const safewordType = document.getElementById('safeword').value;
            
            if (safewordType === 'custom') {
                this.surveyData.safeword = document.getElementById('customSafeword').value || 'RED';
            } else {
                this.surveyData.safeword = safewordType;
            }
        }

        const categories = Object.keys(FETISH_DATA);
        if (this.currentStep >= categories.length) {
            this.completeSurvey();
            return;
        }

        this.currentStep++;
        this.renderStep();
        window.scrollTo(0, 0);
    },

    prevStep() {
        if (this.currentStep > 0) {
            this.currentStep--;
            this.renderStep();
            window.scrollTo(0, 0);
        }
    },

    completeSurvey() {
        const prompt = PromptGenerator.generate(this.surveyData);
        
        localStorage.setItem('survey_' + this.sessionId + '_complete', JSON.stringify({
            prompt,
            timestamp: Date.now()
        }));

        // Redirect to dom view
        window.location.hash = this.sessionId + '_complete';
        location.reload();
    }
};
