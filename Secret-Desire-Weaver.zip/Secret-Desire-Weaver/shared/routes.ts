import { z } from 'zod';
import { insertSurveySchema, insertResponseSchema, surveys } from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  surveys: {
    create: {
      method: 'POST' as const,
      path: '/api/surveys',
      input: insertSurveySchema,
      responses: {
        201: z.object({
          publicId: z.string(),
          domToken: z.string(),
          domName: z.string(),
          subName: z.string(),
        }),
        400: errorSchemas.validation,
      },
    },
    getDashboard: {
      method: 'GET' as const,
      path: '/api/surveys/dashboard/:domToken',
      responses: {
        200: z.object({
          id: z.number(),
          domName: z.string(),
          subName: z.string(),
          sceneLength: z.number(),
          status: z.string(),
          domBackstory: z.string().nullable(),
          generatedStory: z.string().nullable(),
          hasSubResponded: z.boolean(),
        }),
        404: errorSchemas.notFound,
      },
    },
    updateSpice: {
      method: 'POST' as const,
      path: '/api/surveys/dashboard/:domToken/spice',
      input: z.object({ backstory: z.string() }),
      responses: {
        200: z.object({ success: z.boolean() }),
        404: errorSchemas.notFound,
      },
    },
    getByPublicId: {
      method: 'GET' as const,
      path: '/api/surveys/:publicId',
      responses: {
        200: z.object({
          id: z.number(),
          publicId: z.string(),
          domName: z.string(),
          subName: z.string(),
          sceneLength: z.number(),
          status: z.string(),
          // NO generatedStory here!
        }),
        404: errorSchemas.notFound,
      },
    },
    submitResponse: {
      method: 'POST' as const,
      path: '/api/surveys/:publicId/response',
      input: insertResponseSchema,
      responses: {
        200: z.object({
          success: z.boolean(),
        }),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    generateStory: {
      method: 'POST' as const,
      path: '/api/surveys/:publicId/generate',
      responses: {
        200: z.object({
          story: z.string(),
          prompt: z.string(),
        }),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
  },
};

// ============================================
// HELPER
// ============================================
export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
