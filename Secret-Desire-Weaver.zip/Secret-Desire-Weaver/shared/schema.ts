import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

// Stores the main session/survey info
export const surveys = pgTable("surveys", {
  id: serial("id").primaryKey(),
  publicId: text("public_id").notNull().unique(), // Link for the Sub
  domToken: text("dom_token").notNull().unique(), // Secret link for the Dom dashboard
  domName: text("dom_name").notNull(),
  subName: text("sub_name").notNull(),
  sceneLength: integer("scene_length").default(1).notNull(),
  status: text("status").default("created").notNull(), // 'created', 'responded', 'completed'
  domBackstory: text("dom_backstory"), // Extra spice/context from Dom
  generatedPrompt: text("generated_prompt"),
  generatedStory: text("generated_story"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Stores the Sub's responses (kept private from Dom view in UI, but stored here)
export const responses = pgTable("responses", {
  id: serial("id").primaryKey(),
  surveyId: integer("survey_id").notNull().references(() => surveys.id),
  hardLimits: text("hard_limits"),
  safeword: text("safeword"),
  preferences: jsonb("preferences").$type<Record<string, { value: number; hardNo: boolean }>>().notNull(),
  submittedAt: timestamp("submitted_at").defaultNow().notNull(),
});

// === SCHEMAS ===

export const insertSurveySchema = createInsertSchema(surveys).pick({
  domName: true,
  subName: true,
  sceneLength: true,
});

export const insertResponseSchema = createInsertSchema(responses).pick({
  hardLimits: true,
  safeword: true,
  preferences: true,
});

// === TYPES ===

export type Survey = typeof surveys.$inferSelect;
export type InsertSurvey = z.infer<typeof insertSurveySchema>;

export type Response = typeof responses.$inferSelect;
export type InsertResponse = z.infer<typeof insertResponseSchema>;

// Request types
export type CreateSurveyRequest = InsertSurvey;
export type SubmitResponseRequest = InsertResponse;

// AI Generation types
export type GenerateStoryRequest = {
  surveyId: number;
};

export type StoryResponse = {
  story: string;
  prompt: string;
};
