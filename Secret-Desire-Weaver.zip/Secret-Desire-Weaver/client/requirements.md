## Packages
framer-motion | Complex animations for the survey wizard and page transitions
react-markdown | Rendering the markdown-formatted AI stories beautifully
clsx | Utility for conditional classes (standard in shadcn-like setups)
tailwind-merge | Utility for merging tailwind classes (standard in shadcn-like setups)

## Notes
- Tailwind config should extend colors for 'luxury-black' (#050505) and 'crimson' (#dc2626)
- Fonts: Playfair Display (Headers) and Manrope (Body) via Google Fonts
