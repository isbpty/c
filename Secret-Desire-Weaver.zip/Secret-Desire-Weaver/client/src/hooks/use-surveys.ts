import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import type { CreateSurveyRequest, SubmitResponseRequest } from "@shared/schema";

// GET /api/surveys/:publicId
export function useSurvey(publicId: string) {
  return useQuery({
    queryKey: [api.surveys.getByPublicId.path, publicId],
    queryFn: async () => {
      const url = buildUrl(api.surveys.getByPublicId.path, { publicId });
      const res = await fetch(url);
      
      if (!res.ok) {
        if (res.status === 404) return null;
        throw new Error("Failed to fetch survey");
      }
      
      return api.surveys.getByPublicId.responses[200].parse(await res.json());
    },
    enabled: !!publicId,
  });
}

// POST /api/surveys
export function useCreateSurvey() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (data: CreateSurveyRequest) => {
      const res = await fetch(api.surveys.create.path, {
        method: api.surveys.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const error = await res.json().catch(() => ({}));
        throw new Error(error.message || "Failed to create survey");
      }

      return api.surveys.create.responses[201].parse(await res.json());
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// POST /api/surveys/:publicId/response
export function useSubmitResponse() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ publicId, data }: { publicId: string; data: SubmitResponseRequest }) => {
      const url = buildUrl(api.surveys.submitResponse.path, { publicId });
      const res = await fetch(url, {
        method: api.surveys.submitResponse.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        throw new Error("Failed to submit response");
      }

      return api.surveys.submitResponse.responses[200].parse(await res.json());
    },
    onSuccess: (_, { publicId }) => {
      toast({
        title: "Submitted",
        description: "Your preferences have been securely saved.",
      });
      queryClient.invalidateQueries({ queryKey: [api.surveys.getByPublicId.path, publicId] });
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// POST /api/surveys/:publicId/generate
export function useGenerateStory() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (publicId: string) => {
      const url = buildUrl(api.surveys.generateStory.path, { publicId });
      const res = await fetch(url, {
        method: api.surveys.generateStory.method,
      });

      if (!res.ok) {
        const error = await res.json().catch(() => ({}));
        throw new Error(error.message || "Failed to generate story");
      }

      return api.surveys.generateStory.responses[200].parse(await res.json());
    },
    onSuccess: (_, publicId) => {
      toast({
        title: "Scene Generated",
        description: "The AI has crafted your unique experience.",
      });
      queryClient.invalidateQueries({ queryKey: [api.surveys.getByPublicId.path, publicId] });
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
