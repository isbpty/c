import React from 'react';
import { motion } from 'framer-motion';

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen w-full bg-background text-foreground overflow-hidden luxury-gradient selection:bg-primary/30">
      <nav className="absolute top-0 w-full p-6 flex justify-between items-center z-50">
        <a href="/" className="text-xl font-bold font-serif tracking-widest text-white/90 hover:text-primary transition-colors">
          VELVET<span className="text-primary">PROTOCOL</span>
        </a>
      </nav>
      
      <main className="relative z-10 min-h-screen flex flex-col items-center justify-center p-4 md:p-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="w-full max-w-5xl mx-auto"
        >
          {children}
        </motion.div>
      </main>

      {/* Ambient background effects */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-900/5 rounded-full blur-[120px]" />
      </div>
    </div>
  );
}
