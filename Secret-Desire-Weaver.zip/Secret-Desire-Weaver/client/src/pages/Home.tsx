import { useState } from "react";
import { useLocation } from "wouter";
import { useCreateSurvey } from "@/hooks/use-surveys";
import { Layout } from "@/components/ui/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Loader2, Flame, Share2, Lock } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();
  const createSurvey = useCreateSurvey();
  
  const [formData, setFormData] = useState({
    domName: "",
    subName: "",
    sceneLength: 1, // 1-3 (Short, Medium, Long)
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const result = await createSurvey.mutateAsync({
        domName: formData.domName,
        subName: formData.subName,
        sceneLength: formData.sceneLength,
      });
      setLocation(`/dashboard/${result.domToken}`);
    } catch (error) {
      // Handled by hook
    }
  };

  const getLengthLabel = (val: number) => {
    switch(val) {
      case 1: return "Quick Scene (15-30m)";
      case 2: return "Full Session (1-2h)";
      case 3: return "Day Long Challenge";
      default: return "Medium";
    }
  };

  return (
    <Layout>
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        {/* Left Content */}
        <div className="space-y-6 text-center lg:text-left">
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-white leading-tight">
            Design Your <br/>
            <span className="text-primary italic">Perfect Scene</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-md mx-auto lg:mx-0">
            A consensual experience creator. Invite your partner to share their deepest desires without revealing the specifics. AI crafts the perfect scenario for you to act out.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start text-sm text-muted-foreground pt-4">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-primary" />
              <span>Private & Secure</span>
            </div>
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-primary" />
              <span>AI Powered Storytelling</span>
            </div>
          </div>
        </div>

        {/* Right Form */}
        <Card className="p-8 bg-card/50 backdrop-blur-md border-border/50 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-50" />
          
          <form onSubmit={handleSubmit} className="space-y-8 relative z-10">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="domName" className="text-base">Dominant's Name</Label>
                <Input 
                  id="domName"
                  placeholder="e.g. Master, Mistress, or Name"
                  className="bg-background/50 border-input/50 h-12 text-lg focus:border-primary/50 transition-all"
                  value={formData.domName}
                  onChange={(e) => setFormData(prev => ({ ...prev, domName: e.target.value }))}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="subName" className="text-base">Submissive's Name</Label>
                <Input 
                  id="subName"
                  placeholder="e.g. Pet, slave, or Name"
                  className="bg-background/50 border-input/50 h-12 text-lg focus:border-primary/50 transition-all"
                  value={formData.subName}
                  onChange={(e) => setFormData(prev => ({ ...prev, subName: e.target.value }))}
                  required
                />
              </div>

              <div className="space-y-4 pt-2">
                <div className="flex justify-between items-baseline">
                  <Label className="text-base">Desired Intensity & Length</Label>
                  <span className="text-sm text-primary font-medium">
                    {getLengthLabel(formData.sceneLength)}
                  </span>
                </div>
                <Slider 
                  min={1} 
                  max={3} 
                  step={1} 
                  value={[formData.sceneLength]} 
                  onValueChange={(val) => setFormData(prev => ({ ...prev, sceneLength: val[0] }))}
                  className="py-4"
                />
              </div>
            </div>

            <Button 
              type="submit" 
              size="lg" 
              className="w-full text-lg font-serif tracking-widest bg-gradient-to-r from-red-900 to-primary hover:from-red-800 hover:to-red-600 transition-all duration-300"
              disabled={createSurvey.isPending}
            >
              {createSurvey.isPending ? (
                <span className="flex items-center gap-2">
                  <Loader2 className="animate-spin" /> Creating Space...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  Create Experience <Share2 className="w-4 h-4" />
                </span>
              )}
            </Button>
          </form>
        </Card>
      </div>
    </Layout>
  );
}
