import { useEffect, useState } from "react";
import { useRoute, useLocation } from "wouter";
import { useSurvey, useSubmitResponse } from "@/hooks/use-surveys";
import { Layout } from "@/components/ui/layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Loader2, ArrowRight, ArrowLeft, CheckCircle2, ShieldAlert } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { FETISH_CATEGORIES } from "@/data/fetishes";

// Type needed for the preferences map
type PreferenceValue = { value: number; hardNo: boolean };

export default function Survey() {
  const [match, params] = useRoute("/survey/:publicId");
  const [, setLocation] = useLocation();
  const publicId = params?.publicId || "";
  
  const { data: survey, isLoading, error } = useSurvey(publicId);
  const submitResponse = useSubmitResponse();

  const [step, setStep] = useState(0); // 0 = Welcome, 1 = Limits, 2... = Categories
  const [limits, setLimits] = useState({ hardLimits: "", safeword: "Red" });
  const [preferences, setPreferences] = useState<Record<string, PreferenceValue>>({});

  // Initialize preferences if empty
  useEffect(() => {
    if (Object.keys(preferences).length === 0) {
      const initial: Record<string, PreferenceValue> = {};
      FETISH_CATEGORIES.forEach(cat => {
        cat.items.forEach(item => {
          initial[item.id] = { value: 5, hardNo: false }; // Default neutral 5
        });
      });
      setPreferences(initial);
    }
  }, []);

  const totalSteps = FETISH_CATEGORIES.length + 2;
  const progress = ((step) / totalSteps) * 100;

  const handleNext = () => setStep(prev => prev + 1);
  const handleBack = () => setStep(prev => Math.max(0, prev - 1));

  const handleSubmit = async () => {
    if (!survey) return;
    try {
      await submitResponse.mutateAsync({
        publicId: survey.publicId,
        data: {
          hardLimits: limits.hardLimits,
          safeword: limits.safeword,
          preferences,
        },
      });
      setStep(totalSteps + 1); // Success state
    } catch (err) {
      console.error(err);
    }
  };

  const updatePreference = (itemId: string, updates: Partial<PreferenceValue>) => {
    setPreferences(prev => ({
      ...prev,
      [itemId]: { ...prev[itemId], ...updates }
    }));
  };

  if (isLoading) return (
    <Layout>
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-primary">
        <Loader2 className="w-12 h-12 animate-spin mb-4" />
        <p className="text-lg font-serif tracking-widest animate-pulse">Summoning Protocol...</p>
      </div>
    </Layout>
  );

  if (error || !survey) return (
    <Layout>
      <div className="text-center space-y-4">
        <h1 className="text-3xl text-destructive font-serif">Access Denied</h1>
        <p className="text-muted-foreground">This session link is invalid or has expired.</p>
        <Button onClick={() => setLocation("/")} variant="outline">Return Home</Button>
      </div>
    </Layout>
  );

  // Success Screen
  if (step > totalSteps) {
    return (
      <Layout>
        <Card className="max-w-xl mx-auto p-12 text-center border-primary/20 bg-card/60 backdrop-blur-xl">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex flex-col items-center gap-6"
          >
            <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center">
              <CheckCircle2 className="w-10 h-10 text-primary" />
            </div>
            <h2 className="text-4xl font-serif text-white">Submission Received</h2>
            <p className="text-lg text-muted-foreground">
              Your desires have been encrypted and sent to the vault. 
              <span className="text-primary font-semibold"> {survey.domName} </span> 
              will now receive a scenario tailored to your shared compatibility.
            </p>
            <div className="pt-8">
              <p className="text-sm text-muted-foreground italic">"Trust is the greatest aphrodisiac."</p>
            </div>
          </motion.div>
        </Card>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-2xl mx-auto space-y-8">
        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs uppercase tracking-widest text-muted-foreground">
            <span>Progress</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-1 bg-secondary" />
        </div>

        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div
              key="welcome"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="p-8 border-primary/20 shadow-2xl space-y-6">
                <div className="space-y-2">
                  <h1 className="text-4xl font-serif text-white">Hello, {survey.subName}.</h1>
                  <p className="text-xl text-muted-foreground">
                    <span className="text-primary font-semibold">{survey.domName}</span> has invited you to a session.
                  </p>
                </div>
                <div className="space-y-4 text-muted-foreground leading-relaxed">
                  <p>
                    This tool allows you to safely communicate your desires and limits. 
                    Your specific answers (ratings) will remain <strong className="text-white">hidden</strong> from {survey.domName}. 
                  </p>
                  <p>
                    Instead, AI will generate a unique story and set of instructions for them based on what you match on. 
                    This preserves the mystery while ensuring safety.
                  </p>
                </div>
                <Button onClick={handleNext} size="lg" className="w-full text-lg mt-4">
                  Begin Protocol <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </Card>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div
              key="limits"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="p-8 space-y-8 border-l-4 border-l-primary/50">
                <div className="flex items-start gap-4">
                  <ShieldAlert className="w-8 h-8 text-primary mt-1" />
                  <div>
                    <h2 className="text-2xl font-serif text-white">Safety Protocols</h2>
                    <p className="text-muted-foreground">Establish your absolute boundaries.</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="safeword">Safeword</Label>
                    <Input 
                      id="safeword" 
                      value={limits.safeword} 
                      onChange={(e) => setLimits(l => ({ ...l, safeword: e.target.value }))}
                      className="border-primary/30 focus:border-primary"
                    />
                    <p className="text-xs text-muted-foreground">The word that immediately stops all action.</p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="hardLimits">Hard Limits (Things you will NEVER do)</Label>
                    <Textarea 
                      id="hardLimits" 
                      placeholder="e.g. No blood play, no breath play..."
                      value={limits.hardLimits}
                      onChange={(e) => setLimits(l => ({ ...l, hardLimits: e.target.value }))}
                      className="min-h-[120px] bg-secondary/30"
                    />
                  </div>
                </div>

                <div className="flex gap-4 pt-4">
                  <Button variant="ghost" onClick={handleBack}>Back</Button>
                  <Button onClick={handleNext} className="flex-1">Continue</Button>
                </div>
              </Card>
            </motion.div>
          )}

          {step >= 2 && step < totalSteps && (
            <motion.div
              key={`cat-${step}`}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="p-6 md:p-8 space-y-6">
                <div className="border-b border-white/10 pb-4 mb-6">
                  <h2 className="text-2xl font-serif text-primary">
                    {FETISH_CATEGORIES[step - 2].title}
                  </h2>
                  <p className="text-sm text-muted-foreground mt-1">Rate your interest from 0 (Neutral) to 10 (High Desire).</p>
                </div>

                <div className="space-y-8">
                  {FETISH_CATEGORIES[step - 2].items.map((item) => {
                    const pref = preferences[item.id] || { value: 5, hardNo: false };
                    
                    return (
                      <div key={item.id} className={`space-y-3 transition-opacity duration-300 ${pref.hardNo ? 'opacity-50' : 'opacity-100'}`}>
                        <div className="flex items-center justify-between">
                          <Label className="text-base font-medium">{item.label}</Label>
                          {pref.hardNo ? (
                            <span className="text-xs font-bold text-destructive uppercase tracking-widest border border-destructive px-2 py-0.5 rounded">Hard No</span>
                          ) : (
                            <span className="text-sm font-mono text-primary">{pref.value}/10</span>
                          )}
                        </div>
                        
                        {item.description && (
                          <p className="text-xs text-muted-foreground -mt-2">{item.description}</p>
                        )}

                        <div className="flex items-center gap-4">
                          <Slider 
                            disabled={pref.hardNo}
                            min={0} max={10} step={1}
                            value={[pref.value]}
                            onValueChange={(val) => updatePreference(item.id, { value: val[0] })}
                            className="flex-1"
                          />
                          
                          <div className="flex items-center space-x-2 min-w-[100px] justify-end">
                            <Checkbox 
                              id={`no-${item.id}`} 
                              checked={pref.hardNo}
                              onCheckedChange={(checked) => updatePreference(item.id, { hardNo: checked === true })}
                              className="border-muted-foreground/50 data-[state=checked]:bg-destructive data-[state=checked]:border-destructive"
                            />
                            <Label htmlFor={`no-${item.id}`} className="text-xs cursor-pointer text-muted-foreground hover:text-white">
                              Hard No
                            </Label>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="flex gap-4 pt-8 border-t border-white/5 mt-8">
                  <Button variant="ghost" onClick={handleBack}>Back</Button>
                  <Button onClick={step === totalSteps - 1 ? handleSubmit : handleNext} className="flex-1" disabled={submitResponse.isPending}>
                    {submitResponse.isPending ? (
                      <Loader2 className="animate-spin" />
                    ) : step === totalSteps - 1 ? (
                      "Submit Preferences"
                    ) : (
                      "Next Category"
                    )}
                  </Button>
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Layout>
  );
}
