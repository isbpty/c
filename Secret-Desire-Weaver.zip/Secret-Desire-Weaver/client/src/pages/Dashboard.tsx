import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { api, buildUrl } from "@shared/routes";
import { Layout } from "@/components/ui/layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Loader2, Copy, CheckCircle2, Flame, Share2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { queryClient } from "@/lib/queryClient";

interface DashboardData {
  id: number;
  publicId: string;
  domName: string;
  subName: string;
  sceneLength: number;
  status: string;
  domBackstory: string | null;
  generatedStory: string | null;
  hasSubResponded: boolean;
}

export default function Dashboard() {
  const [, params] = useRoute("/dashboard/:domToken");
  const domToken = params?.domToken;
  const { toast } = useToast();
  const [backstory, setBackstory] = useState("");

  const { data: survey, isLoading, error } = useQuery<DashboardData>({
    queryKey: [buildUrl(api.surveys.getDashboard.path, { domToken: domToken! })],
    enabled: !!domToken,
  });

  const updateSpiceMutation = useMutation({
    mutationFn: async (text: string) => {
      const res = await fetch(buildUrl(api.surveys.updateSpice.path, { domToken: domToken! }), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ backstory: text }),
      });
      if (!res.ok) throw new Error("Failed to update spice");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Vision Updated", description: "Your partner's scene will be flavored by your words." });
      queryClient.invalidateQueries({ queryKey: [buildUrl(api.surveys.getDashboard.path, { domToken: domToken! })] });
    }
  });

  const generateStoryMutation = useMutation({
    mutationFn: async () => {
      if (!survey?.publicId) throw new Error("Missing publicId");
      const res = await fetch(buildUrl(api.surveys.generateStory.path, { publicId: survey.publicId }), { 
        method: "POST",
      });
      if (!res.ok) throw new Error("Generation failed");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Scene Manifested", description: "The story is ready for your eyes only." });
      queryClient.invalidateQueries({ queryKey: [buildUrl(api.surveys.getDashboard.path, { domToken: domToken! })] });
    }
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Link Copied", description: "Share this with your partner." });
  };

  if (isLoading) return <div className="flex h-screen items-center justify-center"><Loader2 className="animate-spin text-primary" /></div>;
  if (error || !survey) return <Layout><div className="text-center text-red-500">Error loading dashboard.</div></Layout>;

  const subLink = `${window.location.origin}/survey/${survey.publicId}`;

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8">
        <header className="space-y-2">
          <h1 className="text-4xl font-bold tracking-tight">Dominant Dashboard</h1>
          <p className="text-muted-foreground">Managing session for {survey.subName}</p>
        </header>

        <div className="grid md:grid-cols-2 gap-6">
          <Card className="p-6 space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Share2Icon className="w-5 h-5 text-primary" /> Share Link
            </h2>
            <p className="text-sm text-muted-foreground">Send this secret link to your partner. They will fill out their preferences anonymously.</p>
            <div className="flex gap-2">
              <div className="bg-background/50 border rounded px-3 py-2 text-sm font-mono flex-1 overflow-hidden truncate">
                {subLink}
              </div>
              <Button size="icon" variant="outline" onClick={() => copyToClipboard(subLink)}>
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </Card>

          <Card className="p-6 space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <CheckCircle2 className={`w-5 h-5 ${survey.hasSubResponded ? 'text-green-500' : 'text-muted'}`} /> Status
            </h2>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Sub Response:</span>
                <span className={survey.hasSubResponded ? "text-green-500 font-bold" : "text-yellow-500"}>
                  {survey.hasSubResponded ? "READY" : "WAITING"}
                </span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary transition-all duration-500" 
                  style={{ width: survey.hasSubResponded ? "100%" : "50%" }}
                />
              </div>
            </div>
          </Card>
        </div>

        <Card className="p-6 space-y-4">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Flame className="w-5 h-5 text-primary" /> Add Your Vision (Spice)
          </h2>
          <p className="text-sm text-muted-foreground">The AI will weave your specific context, backstory, or desires into the final scene alongside their preferences.</p>
          <Textarea 
            placeholder="e.g. You are a high-ranking officer and they are your captive... or perhaps just a cozy rainy afternoon session."
            value={backstory || survey.domBackstory || ""}
            onChange={(e) => setBackstory(e.target.value)}
            className="min-h-[120px]"
          />
          <Button 
            onClick={() => updateSpiceMutation.mutate(backstory)}
            disabled={updateSpiceMutation.isPending}
            className="w-full"
          >
            Update Vision
          </Button>
        </Card>

        {survey.hasSubResponded && (
          <div className="pt-8 border-t border-border/50">
            {survey.generatedStory ? (
              <Card className="p-8 space-y-6 bg-red-950/10 border-primary/20">
                <h2 className="text-3xl font-serif italic text-primary">The Manifested Scene</h2>
                <div className="prose prose-invert max-w-none whitespace-pre-wrap leading-relaxed text-lg">
                  {survey.generatedStory}
                </div>
              </Card>
            ) : (
              <Button 
                size="lg" 
                className="w-full h-16 text-xl font-serif tracking-widest bg-primary"
                onClick={() => generateStoryMutation.mutate()}
                disabled={generateStoryMutation.isPending}
              >
                {generateStoryMutation.isPending ? <Loader2 className="animate-spin mr-2" /> : <Flame className="mr-2" />}
                GENERATE THE EXPERIENCE
              </Button>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
}

function Share2Icon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="18" cy="5" r="3" />
      <circle cx="6" cy="12" r="3" />
      <circle cx="18" cy="19" r="3" />
      <path d="m8.59 13.51 6.83 3.98" />
      <path d="m15.41 6.49-6.82 3.98" />
    </svg>
  )
}
