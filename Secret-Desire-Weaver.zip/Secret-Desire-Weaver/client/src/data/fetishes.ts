export interface FetishItem {
  id: string;
  label: string;
  description?: string;
}

export interface FetishCategory {
  id: string;
  title: string;
  items: FetishItem[];
}

export const FETISH_CATEGORIES: FetishCategory[] = [
  {
    id: "general",
    title: "General Dynamics",
    items: [
      { id: "power_exchange", label: "Power Exchange", description: "Giving or taking control" },
      { id: "discipline", label: "Discipline", description: "Punishment and correction" },
      { id: "protocol", label: "Protocol & Etiquette", description: "Specific rules for posture, speech, or behavior" },
      { id: "service", label: "Service", description: "Performing tasks or caring for the Dom" },
    ]
  },
  {
    id: "bondage",
    title: "Bondage & Restriction",
    items: [
      { id: "rope", label: "Rope Bondage" },
      { id: "cuffs", label: "Handcuffs & Restraints" },
      { id: "blindfolds", label: "Blindfolds / Sensory Deprivation" },
      { id: "gags", label: "Gags & Silencing" },
      { id: "suspension", label: "Suspension Bondage" },
    ]
  },
  {
    id: "impact",
    title: "Impact Play",
    items: [
      { id: "spanking", label: "Hand Spanking" },
      { id: "paddles", label: "Paddles / Crops" },
      { id: "whips", label: "Whips / Floggers" },
      { id: "caning", label: "Caning" },
    ]
  },
  {
    id: "sensation",
    title: "Sensation Play",
    items: [
      { id: "wax", label: "Hot Wax Play" },
      { id: "ice", label: "Ice / Temperature Play" },
      { id: "tickling", label: "Tickling" },
      { id: "electro", label: "Electro / TENS Unit" },
    ]
  },
  {
    id: "psychological",
    title: "Psychological",
    items: [
      { id: "praise", label: "Praise & Affirmation" },
      { id: "humiliation", label: "Humiliation / Degradation" },
      { id: "objectification", label: "Objectification" },
      { id: "fear", label: "Fear Play / Primal Fear" },
    ]
  },
  {
    id: "roleplay",
    title: "Roleplay & Scenarios",
    items: [
      { id: "teacher_student", label: "Teacher / Student" },
      { id: "boss_secretary", label: "Boss / Employee" },
      { id: "doctor_patient", label: "Medical / Clinical" },
      { id: "pet_play", label: "Pet Play (Puppy, Kitten, etc.)" },
    ]
  },
  {
    id: "advanced",
    title: "Advanced & Edge",
    items: [
      { id: "breath", label: "Breath Control" },
      { id: "knife", label: "Knife Play" },
      { id: "blood", label: "Blood Play" },
      { id: "cnc", label: "Consensual Non-Consent" },
    ]
  }
];
